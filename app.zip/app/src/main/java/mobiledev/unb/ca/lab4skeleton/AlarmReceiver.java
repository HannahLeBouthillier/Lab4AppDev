package mobiledev.unb.ca.lab4skeleton;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.util.Log;
import java.util.*;

import static android.content.ContentValues.TAG;
import static android.provider.Settings.Global.getString;

public class AlarmReceiver extends BroadcastReceiver {


    @Override
    public void onReceive(Context mainActContext, Intent intent) {
        Log.i(TAG, "onReiececcncn");

        createNotificationChannel(mainActContext);

        Intent tapIntent = new Intent(mainActContext, AlarmReceiver.class);
        tapIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(mainActContext, 0, tapIntent, 0);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(mainActContext, "channel1")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentIntent(pendingIntent)
                .setContentTitle("ALARM TITLE")
                .setContentText("ALARM TEXT")
                .setPriority(NotificationManager.IMPORTANCE_HIGH)
                .setAutoCancel(true);

        NotificationManager notificationManager = (NotificationManager)mainActContext.getSystemService(Context.NOTIFICATION_SERVICE);
        int notificationID = 1; //(new Random(420).nextInt());
        notificationManager.notify(notificationID, builder.build());
    }

    private void createNotificationChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "ALARM NAME";
            String description = "ALARM DESCRIPTION";
            int importence = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel chan = new NotificationChannel("channel1", name, importence);
            chan.setDescription(description);
            NotificationManager notificationManager = context.getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(chan);
        }
    }
}
